import {
  checkVisa,
  checkMastercard,
  checkAmericanCard,
  checkDiscoverCard,
} from "./checkpaysystem";

const mockElement = () => {
  return {
    classList: {
      classes: new Set(),
      add(cls) {
        this.classes.add(cls);
      },
      remove(cls) {
        this.classes.delete(cls);
      },
      contains(cls) {
        return this.classes.has(cls);
      },
    },
  };
};

describe("check pay system", () => {
  let visa, mastercard, american, discover;
  beforeEach(() => {
    visa = mockElement();
    mastercard = mockElement();
    american = mockElement();
    discover = mockElement();
  });
  test("check visa", () => {
    checkVisa("4929169365290469568", visa);
    expect(visa.classList.contains("active")).toBe(true);
  });
});
