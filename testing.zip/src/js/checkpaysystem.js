const checkVisa = (numberCard, visa) => {
  const checkLengthVisa =
    numberCard.length === 13 ||
    numberCard.length === 16 ||
    numberCard.length === 19;
  if (numberCard.startsWith("4") && checkLengthVisa) {
    visa.classList.add("active");
    // console.log('jjkj')
  } else {
    visa.classList.remove("active");
  }
};

const checkMastercard = (numberCard, mastercard) => {
  // console.log( typeof numberCard)
  const firstNumbers = numberCard.slice(0, 4); // 4 не включительно
  // console.log(firstNumbers)
  const firstCheck = firstNumbers >= 2221 && firstNumbers <= 2720;
  const firstTwoNumbers = numberCard.slice(0, 2);
  const secondCheck = firstTwoNumbers >= 51 && firstTwoNumbers <= 55;
  if (numberCard.length === 16 && (firstCheck || secondCheck)) {
    mastercard.classList.add("active");
  } else {
    mastercard.classList.remove("active");
  }
};

const checkAmericanCard = (numberCard, american) => {
  const firstTwoNumbers = Number(numberCard.slice(0, 2));
  // console.log(typeof firstTwoNumbers, firstTwoNumbers)
  const secondCheck = firstTwoNumbers === 34 || firstTwoNumbers === 37;
  if (numberCard.length === 15 && secondCheck) {
    american.classList.add("active");
    console.log("сработало");
  } else {
    american.classList.remove("active");
    console.log(numberCard.length);
  }
};

const checkDiscoverCard = (numberCard, discover) => {
  const firstCheck = numberCard.length >= 16 && numberCard.length <= 19;
  const firstNumbers = numberCard.slice(0, 4);
  const secondCheck =
    firstNumbers == 6011 ||
    firstNumbers.slice(0, 2) == 65 ||
    (firstNumbers.slice(0, 3) >= 644 && firstNumbers.slice(0, 3) <= 649);
  if (firstCheck && secondCheck) {
    discover.classList.add("active");
  } else {
    discover.classList.remove("active");
  }
};

export { checkVisa, checkMastercard, checkAmericanCard, checkDiscoverCard };
