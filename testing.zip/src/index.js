import "./css/style.css";

import "./js/app";

// const string = '567567576576'
// const firstNumbers = Number(string.slice(0, 4))
// console.log(typeof firstNumbers, firstNumbers)
